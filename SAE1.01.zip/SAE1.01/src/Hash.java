import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Hash {
    public static byte[] checksum(byte[] data) {
        try {
            // Initialisation avec l'algorithme MD5
            MessageDigest md = MessageDigest.getInstance("MD5");

            // Calcul du hash
            byte[] messageDigest = md.digest(data);

            return messageDigest;

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Algorithme MD5 non trouvé", e);
        }
    }

    // transforme une image en GL en un tableau de byte ( format nécessaire pour le fournire a l'algorithme de hashage)
    public static byte[] hashImage(int[][] imageGL) {
        int height = imageGL.length;
        int width = imageGL[0].length;

        // Création d'un tableau de bytes pour tous les pixels
        byte[] allPixels = new byte[height * width];
        int index = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                allPixels[index++] = (byte) imageGL[y][x];
            }
        }
        return checksum(allPixels);
    }
}